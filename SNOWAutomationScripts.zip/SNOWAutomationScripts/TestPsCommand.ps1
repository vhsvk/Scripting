param([string]$parm)
Write-Host 'Hello' $parm