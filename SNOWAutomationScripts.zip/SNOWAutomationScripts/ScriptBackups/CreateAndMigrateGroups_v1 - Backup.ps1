﻿#Author: Muhammad Ibrahim
#Script create OUs, Groups and GPO to automate the VM deployment in public cloud
param(
[string]$AD_Environment,
[string]$platform,
[string]$AppOU,
[string]$serviceTypeOU,
[string]$OldOUPath,
[string]$VMOUPath
)

whoami

Import-Module ActiveDirectory
Import-Module GroupPolicy


#Import-Module activedirectory
#$PathToLines = $OldOUPath.split(',')
#$ad_Environment = $PathToLines[1].Substring(3)
#$serviceTypeOU= $PathToLines[0].Substring(3)
#$AppOU = $PathToLines[2].Substring(3)
#$platform = "SPD-Azure"
$cloudplatform = $platform.Substring(4)

$NewGroupOUPath = "OU=$serviceTypeOU,OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com"
$NewGroupAppOUPath = "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com"
$serviceOUFullPath = "OU=$AppOU,OU=$ad_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=Centricaplc,DC=com"
$VMOUPath = "OU=$serviceTypeOU,OU=$AppOU,OU=$ad_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=Centricaplc,DC=com"

#$serviceOUPos = $VMOUPath.IndexOf(",")
#$serviceOUFullPath = $VMOUPath.Substring($serviceOUPos+1)

#$AppOUPos = $serviceOUFullPath.IndexOf(",")
#$AppOUFullPath = $serviceOUFullPath.Substring($AppOUPos+1)

if (Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$serviceOUFullPath'" )
{
 
   if (Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$VMOUPath'" )
   {
     Write-Host "don't create any OU"
     #break

   }
   else
   {   Write-Host "Only Create $serviceTypeOU OU"
       #Create VM OUs
        New-ADOrganizationalUnit -Name $serviceTypeOU -Path "OU=$AppOU,OU=$ad_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false

        #Create Group OU
         if(Get-ADOrganizationalUnit -Filter "distinguishedName" -ne $NewGroupOUPath )
       { New-ADOrganizationalUnit -Name $serviceTypeOU -path "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru}
   }
}
else
{
        #Create VM OUs
        New-ADOrganizationalUnit -Name $AppOU -path "OU=$ad_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru
        New-ADOrganizationalUnit -Name $serviceTypeOU -Path "OU=$AppOU,OU=$ad_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false

        #Create Group OU
        New-ADOrganizationalUnit -Name $AppOU -Path "OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru
        New-ADOrganizationalUnit -Name $serviceTypeOU -Path "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru
}



       if(Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$NewGroupAppOUPath'" )
       { 
        Write-Host "$AppOU under Groups already exists"
       }
       else
       {
         Write-Host "create $AppOU & $serviceTypeOU"
         New-ADOrganizationalUnit -Name $AppOU -path "OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru
         New-ADOrganizationalUnit -Name $serviceTypeOU -path "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru

       }

    
       if(Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$NewGroupOUPath'" )
       {Write-Host "$serviceTypeOU under Groups already Exist"  }
       else
       { New-ADOrganizationalUnit -Name $serviceTypeOU -path "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru}

     




$NewGGroups = @()
$NewDLGroups = @()


$OldGroupList = Get-ADGroup -filter * -SearchBase $OldOUPath  #Get list of Groups under App OU
$NewGlobalGroupList = Get-ADGroup -filter {GroupScope -eq 'Global'} -SearchBase $NewGroupOUPath  #Get list of Groups under App OU

foreach ($oldGroupName in $OldGroupList.name)
{
       
       
        $pos = $oldGroupName.IndexOf("HP")
        $oldGroupNamePermission = $oldGroupName.Substring(2, $pos-3)
        
        $NewGlobalGroupName = "g-$oldGroupNamePermission-$platform-Svrs-BG-$AppOU-$serviceTypeOU"
        $NewDLGroupName = "d-$oldGroupNamePermission-$platform-Svrs-BG-$AppOU-$serviceTypeOU"

        #e.g. OU=SQL,OU=OCM,OU=Dev,OU=BG,OU=SPD-Azure,OU=Groups,DC=uk,DC=centricaplc,DC=com
        $NewGroupOUPath = "OU=$serviceTypeOU,OU=$AppOU,OU=$AD_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com"

        $NewGGroups += New-ADGroup -Name $NewGlobalGroupName -Path $NewGroupOUPath -GroupCategory Security -GroupScope Global -PassThru
        $NewDLGroups += New-ADGroup -Name $NewDLGroupName -Path $NewGroupOUPath -GroupCategory Security -GroupScope DomainLocal -PassThru

        # Make Global Group member of Domain Local Group
          Add-ADGroupMember -Identity $NewDLGroupName -Members $NewGlobalGroupName

        $oldGroupMembers = Get-ADGroupMember -Identity $oldGroupName

        if($oldGroupMembers -ne $null)
        {Add-ADGroupMember -Identity $NewGlobalGroupName -Members $oldGroupMembers -PassThru}
       
        
          
              
}

########################
#######Create GPO#######
######################## 

#clear
$NewDLGroups = $NewDLGroups | sort

$AllUserRightGroups = Get-ADGroup -Filter * -SearchBase "OU=User-Right-Assignments,OU=Groups,DC=uk,DC=centricaplc,DC=com" | sort

$AllServersSeBatchLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Log-on-as-a-batch-job*' -and $_.name -notlike "*Deny-Log-on-as-a-batch-job*"}).SID.Value
$AllServersSeNetworkLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Access-this-computer-from-n*'}).SID.Value
$AllServersSeTcbPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Act-as-part-of-the-os*'}).SID.Value
$AllServersSeIncreaseQuotaPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Adjust-memory-quotas*'}).SID.Value
$AllServersSeInteractiveLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Allow-log-on-locally*'}).SID.Value
$AllServersSeBackupPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Back-up-files*'}).SID.Value
$AllServersSeCreateGlobalPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Create-global-objects*'}).SID.Value
$AllServersSeDebugPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Debug-programs*'}).SID.Value
$AllServersSeDenyNetworkLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Deny-access-from-the-n*'}).SID.Value
$AllServersSeDenyRemoteInteractiveLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Deny-log-on-through-R*'}).SID.Value
$AllServersSeImpersonatePrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Impersonate-client*'}).SID.Value
$AllServersSeLockMemoryPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Lock-pages-in-mem*'}).SID.Value
$AllServersSeServiceLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Log-on-as-a-service*' -and $_.name -notlike "*d-Deny-Log-on-as-a-service*"}).SID.Value
$AllServersSeSecurityPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Manage-auditing*'}).SID.Value
$AllServersSeSystemProfilePrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Profile-system-perf*'}).SID.Value
$AllServersSeAssignPrimaryTokenPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Replace-a-proc*'}).SID.Value
$DenyLogOnTSDomain = (Get-ADGroup -Identity "d-Deny-Log-On-TS-Domain").SID.Value


#Create GPO
#GPO Name Example:  GPO-SPD-Azure-BG-Svrs-Prod-SharedSQLMediumTWO-DB-v1.0
[int]$i = 1
$templateGPO = "GPO-SPD-Azure-BG-Svrs-Prod-ISERVER-Web"
$newGPOName = "GPO-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)-v$i.0"
$GPOExist = 'False'
do{
if (Get-GPO -All -Domain "uk.centricaplc.com" | where {$_.Displayname -eq $newGPOName})
{
Write-Host "$($newGPOName) already exist"
$newGPOName = "GPO-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)-v$i.0" 
$GPOExist = 'True'
}
else
{
$GPOExist = 'False'
$newGPO = Copy-GPO -SourceName $templateGPO -TargetName $newGPOName
}

$i = $i+1
}until ($GPOExist -eq 'False')

cd "\\$env:USERDNSDOMAIN\sysvol\$env:USERDNSDOMAIN\Policies\{$($newGPO.id)}\Machine\microsoft\windows nt\SecEdit"
$GPFilePath = "\\$env:USERDNSDOMAIN\sysvol\$env:USERDNSDOMAIN\Policies\{$($newGPO.id)}\Machine\microsoft\windows nt\SecEdit\GptTmpl.inf"


$lines = Get-Content $GPFilePath
$lines | where { $_ -eq $lines[0] -or $_ -eq $lines[1] -or $_ -eq $lines[2] -or $_ -eq $lines[3] -or $_ -eq $lines[4] } | out-file $GPFilePath
Add-Content -path $GPFilePath -value "[Group Membership]"
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-2].SID.Value)__Memberof = *S-1-5-32-544"
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-2].SID.Value)__Members ="
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-1].SID.Value)__Memberof = *S-1-5-32-555"
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-1].SID.Value)__Members ="
Add-Content -path $GPFilePath -value "[Privilege Rights]"
foreach($group in $NewDLGroups)
{
if($group.name -like "*Log-on-as-a-batch-job*" -and $group.name -notlike "*Deny-Log-on-as-a-batch-job*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeBatchLogonRight = *$AllServersSeBatchLogonRight,*$GroupSID,*S-1-5-32-544,*S-1-5-32-551"
$group.name
}


if($group.name -like "*Access-this-computer-from-n*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeNetworkLogonRight =*S-1-5-11,*S-1-5-32-544,*$AllServersSeNetworkLogonRight,*$GroupSID"
$group.name
}

if($group.name -like "*Act-as-part-of-the-os*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeTcbPrivilege = *$AllServersSeTcbPrivilege,*$GroupSID"
write-host "test $group.name"
}


if($group.name -like "*Adjust-memory-quotas*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeIncreaseQuotaPrivilege = *S-1-5-19,*S-1-5-32-544,*S-1-5-20,*$AllServersSeIncreaseQuotaPrivilege,*$GroupSID"
write-host "test $group.name"
}


if($group.name -like "*Allow-log-on-locally*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeInteractiveLogonRight = *$AllServersSeInteractiveLogonRight,*$GroupSID,*S-1-5-32-544,*S-1-5-32-551,*S-1-5-11"
write-host "test $group.name"
}


if($group.name -like "*Back-up-files*" -or $group.name -like "*Backup-files*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeBackupPrivilege = *$AllServersSeBackupPrivilege,*$GroupSID,*S-1-5-32-544,*S-1-5-32-551"
write-host "test $group.name"
}

if($group.name -like "*Create-global-objects*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeCreateGlobalPrivilege = *$AllServersSeCreateGlobalPrivilege,*$GroupSID,*S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6"
write-host "test $group.name"
}


if($group.name -like "*Debug-programs*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeDebugPrivilege = *S-1-5-32-544,*$AllServersSeDebugPrivilege,*$GroupSID"
write-host "test $group.name"
}


if($group.name -like "*Deny-access-from-the-n*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeDenyNetworkLogonRight = *S-1-5-32-546,*$AllServersSeDenyNetworkLogonRight,*$GroupSID"
write-host "test $group.name"
}

if($group.name -like "*Deny-log-on-through-R*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeDenyRemoteInteractiveLogonRight = *$DenyLogOnTSDomain,*S-1-5-32-546,*$AllServersSeDenyRemoteInteractiveLogonRight,*$GroupSID"
write-host "test $group.name"
}


if($group.name -like "*Impersonate-client*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeImpersonatePrivilege = *$AllServersSeImpersonatePrivilege,*$GroupSID,*S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6"
write-host "test $group.name"
}


if($group.name -like "*Lock-pages-in-mem*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeLockMemoryPrivilege = *$AllServersSeLockMemoryPrivilege,*$GroupSID"
write-host "test $group.name"
}


if($group.name -like "*Log-on-as-a-service*" -and $group.name -notlike "*Deny-Log-on-as-a-service*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeServiceLogonRight = *$AllServersSeServiceLogonRight,*$GroupSID"
write-host "test $group.name"
}


if($group.name -like "*Manage-auditing*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeSecurityPrivilege = *$AllServersSeSecurityPrivilege,*$GroupSID,*S-1-5-32-544"
write-host "test $group.name"
}


if($group.name -like "*Profile-system-perf*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeSystemProfilePrivilege = *$AllServersSeSystemProfilePrivilege,*$GroupSID,*S-1-5-32-544"
write-host "test $group.name"
}


if($group.name -like "*Replace-a-proc*" )
{
$GroupSID=$group.SID.Value
Add-Content -path $GPFilePath -value "SeAssignPrimaryTokenPrivilege = *$AllServersSeAssignPrimaryTokenPrivilege,*$GroupSID,*S-1-5-19,*S-1-5-20"
write-host "test $group.name"
}


} #end foreach($group in $OldGroupList)





# Apply GPO delegation
Set-GPPermission -Name $newGPO.DisplayName -PermissionLevel GpoEdit -TargetName "d-GPO-$platform-BG-$AD_Environment-Edit" -TargetType Group

# Link GPO to the Target OU OU=Web,OU=DevOps,OU=Dev,OU=Servers,OU=BG,OU=SPD-Azure,DC=lab,DC=local
New-GPLink -Guid $newGPO.id -Target "ou=$serviceTypeOU,OU=$AppOU,OU=$AD_Environment,OU=Servers,OU=BG,OU=$platform,DC=UK,DC=Centricaplc,DC=com" -LinkEnabled Yes

