﻿#Author: Muhammad Ibrahim
#Script create OUs, Groups and GPO to automate the VM deployment in public cloud

param
(
[string]$AD_Environment,
[string]$platform,
[string]$parentOUPath
)

whoami

Import-Module ActiveDirectory
Import-Module GroupPolicy

$createGroups = "false"
#$domainSuffix = "DC=lab,DC=local"
$domainSuffix = "DC=uk,DC=centricaplc,DC=com"
$PathToLines = $parentOUPath.split(',')
$serviceTypeOU= $PathToLines[0].Substring(3)
$AppOU = $PathToLines[1].Substring(3)
$cloudplatform = $platform.Substring(4)
$NewGroupOUPath = "OU=$serviceTypeOU,OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com"
$NewGroupAppOUPath = "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com"


if ($serviceTypeOU -eq "App" -or $serviceTypeOU -eq "DB" -or $serviceTypeOU -eq "Web")
{
$AppOUPath = "OU=$AppOU,OU=$AD_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=centricaplc,DC=com"
$serviceTypeOUPath = "OU=$serviceTypeOU,$AppOUPath"

   if (Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$AppOUPath'" ) # checks whether AppOU e.g. Zenoss exists
     {    Write-Host "`n$AppOUPath already exists."
          
        if (Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$serviceTypeOUPath'" ) #checks whether service Type OU exist e.g. DB or App also exist
            {                 
                write-host "`n$serviceTypeOUPath already exist. `n`nDon't create any OU.... `n`nNo further checks requires. Just quit....`n"
                #break
            }
                else
                    {
                        #clear
                        write-host "`nOnly create $serviceTypeOU for service type......`n"
                        #create OU for VM e.g OU=Zenoss,OU=Prod,OU=Servers,OU=BG,OU=SPD-Azure,DC=lab,DC=local
                        New-ADOrganizationalUnit -Name $serviceTypeOU -Path "OU=$AppOU,OU=$AD_Environment,OU=Servers,OU=BG,OU=$Platform,$domainSuffix" -ProtectedFromAccidentalDeletion:$false -Server "ZSCPWDCS001.uk.centricaplc.com"
        
                        #Create OU for Groups e.g. #OU=Zenoss,OU=Prod,OU=BG,OU=Groups,DC=lab,DC=local
                        New-ADOrganizationalUnit -Name $serviceTypeOU -Path "OU=$AppOU,OU=$AD_Environment,OU=BG,OU=$platform,OU=Groups,$domainSuffix" -ProtectedFromAccidentalDeletion:$false -Server "ZSCPWDCS001.uk.centricaplc.com"

                        $createGroups = "true"
                     }
      } #end of Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$AppOUPath'"
        else 
        {
            #clear
            Write-Host "`ncreate New OUs $serviceTypeOU & $AppOU`n"
            #create OU for VM e.g OU=Web,OU=ARMS,OU=Dev,OU=Servers,OU=BG,OU=SPD-Azure,DC=uk,DC=centricaplc,DC=com
            New-ADOrganizationalUnit -Name $AppOU -Path "OU=$AD_Environment,OU=Servers,OU=BG,OU=$Platform,$domainSuffix" -ProtectedFromAccidentalDeletion:$false -Server "ZSCPWDCS001.uk.centricaplc.com"
            New-ADOrganizationalUnit -Name $serviceTypeOU -Path "OU=$AppOU,OU=$AD_Environment,OU=Servers,OU=BG,OU=$Platform,$domainSuffix" -ProtectedFromAccidentalDeletion:$false -Server "ZSCPWDCS001.uk.centricaplc.com"

            #Create OU for Groups e.g. #OU=APP,OU=CE-PI,OU=Dev,OU=BG,OU=SPD-Azure,OU=Groups,DC=uk,DC=centricaplc,DC=com
            New-ADOrganizationalUnit -Name $AppOU -Path "OU=$AD_Environment,OU=BG,OU=$platform,OU=Groups,$domainSuffix" -ProtectedFromAccidentalDeletion:$false -Server "ZSCPWDCS001.uk.centricaplc.com"
            New-ADOrganizationalUnit -Name $serviceTypeOU -Path "OU=$AppOU,OU=$AD_Environment,OU=BG,OU=$platform,OU=Groups,$domainSuffix" -ProtectedFromAccidentalDeletion:$false -Server "ZSCPWDCS001.uk.centricaplc.com"
            $createGroups = "true"
        }
}


## Double check Group OUs and create if they don't exist
      if(Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$NewGroupAppOUPath'" )
       { 
       # Write-Host "$AppOU already exists"
       }
       else
       {
         Write-Host "create $AppOU & $serviceTypeOU"
         New-ADOrganizationalUnit -Name $AppOU -path "OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru -Server "ZSCPWDCS001.uk.centricaplc.com"
         New-ADOrganizationalUnit -Name $serviceTypeOU -path "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru -Server "ZSCPWDCS001.uk.centricaplc.com"

       }

    
       if(Get-ADOrganizationalUnit -Filter "distinguishedName -eq '$NewGroupOUPath'" )
       {
       #Write-Host "$serviceTypeOU already Exist"  
       }
       else
       { New-ADOrganizationalUnit -Name $serviceTypeOU -path "OU=$AppOU,OU=$ad_Environment,OU=BG,OU=$platform,OU=Groups,DC=uk,DC=Centricaplc,DC=com" -ProtectedFromAccidentalDeletion:$false -PassThru -Server "ZSCPWDCS001.uk.centricaplc.com"} 

       
#Create Groups and GPO
$AllUserRightGroups = (Get-ADGroup -Filter * -SearchBase "OU=User-Right-Assignments,OU=Groups,DC=uk,DC=centricaplc,DC=com" -Server "ZSCPWDCS001.uk.centricaplc.com" | sort).name


$NewGroups = @(
"Log-on-as-a-batch-job",
"Log-on-as-a-service",
"Manage-auditing-log",
"Restricted-Groups-Admins",
"Restricted-Groups-RDP"
)


$NewGGroups = @()
$NewDLGroups = @()

foreach ($Group in $NewGroups)
{
#d-<user right>-<OU name> Added to Object ACL for correct permissions
#g-<user right>-<OU name> nested into the domain local group
#Example: d-Lock-Pages-In-Memory-Svrs-AZR-PRD-Adapt-DB
#Example: CN=d-Act-as-part-of-the-OS-SPD-Azure-BG-Svrs-Prod-ARIS-App,OU=App,OU=Aris,OU=Prod,OU=BG,OU=SPD-Azure,OU=Groups,DC=uk,DC=centricaplc,DC=com
$newGGroupName = "g-$($Group)-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)"
$newDLGroupname = "d-$($Group)-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)"

$groupOUPath = "OU=$serviceTypeOU,OU=$AppOU,OU=$AD_Environment,OU=BG,OU=$platform,OU=Groups,$domainSuffix"

if(Get-ADGroup -Filter  "Name -eq '$newGGroupName'" -Server "ZSCPWDCS001.uk.centricaplc.com")
{
Write-Host "$newGGroupName already exist"
}
else
{
$NewGGroups += New-ADGroup -Name "g-$($Group)-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)" -Path $groupOUPath -GroupCategory Security -GroupScope Global -PassThru -Server "ZSCPWDCS001.uk.centricaplc.com"
}



if(Get-ADGroup -Filter  "Name -eq '$newDLGroupname'" -Server "ZSCPWDCS001.uk.centricaplc.com")
{
Write-Host "$newGGroupName already exist"
}
else
{
$NewDLGroups += New-ADGroup -Name "d-$($Group)-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)" -Path $groupOUPath -GroupCategory Security -GroupScope DomainLocal -PassThru -Server "ZSCPWDCS001.uk.centricaplc.com"
# Make Global Group member of Domain Local Group
Add-ADGroupMember -Identity d-$($Group)-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU) -Members g-$($Group)-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU) -Server "ZSCPWDCS001.uk.centricaplc.com"
}

}


#Create GPO
#GPO Name Example:  GPO-SPD-Azure-BG-Svrs-Prod-SharedSQLMediumTWO-DB-v1.0

$NewDLGroups = $NewDLGroups | sort

$AllUserRightGroups = Get-ADGroup -Filter * -SearchBase "OU=User-Right-Assignments,OU=Groups,DC=uk,DC=centricaplc,DC=com" | sort

$AllServersSeBatchLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Log-on-as-a-batch-job*' -and $_.name -notlike "*d-Deny-Log-on-as-a-batch-job*"}).SID.Value
$NewDLSeBatchLogonRight = ($NewDLGroups | where {$_.name -like '*d-Log-on-as-a-batch-job*' -and $_.name -notlike "*d-Deny-Log-on-as-a-batch-job*"}).SID.Value

$AllServersSeServiceLogonRight = ($AllUserRightGroups | where {$_.name -like '*d-Log-on-as-a-service*' -and $_.name -notlike "*d-Deny-Log-on-as-a-service*"}).SID.Value
$NewDLSeServiceLogonRight = ($NewDLGroups | where {$_.name -like '*d-Log-on-as-a-service*' -and $_.name -notlike "*d-Deny-Log-on-as-a-service*"}).SID.Value

$AllServersSeSecurityPrivilege = ($AllUserRightGroups | where {$_.name -like '*d-Manage-auditing*'}).SID.Value
$NewDLSeSecurityPrivilege = ($NewDLGroups | where {$_.name -like '*d-Manage-auditing*'}).SID.Value

#Create GPO
#GPO Name Example:  GPO-SPD-Azure-BG-Svrs-Prod-SharedSQLMediumTWO-DB-v1.0
[int]$i = 1
$templateGPO = "GPO-SPD-Azure-BG-Svrs-Prod-ISERVER-Web"
$newGPOName = "GPO-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)-v$i.0"
$GPOExist = 'False'
do{
if (Get-GPO -All -Domain "uk.centricaplc.com" -Server "ZSCPWDCS001.uk.centricaplc.com"| where {$_.Displayname -eq $newGPOName})
{
Write-Host "$($newGPOName) already exist"
$newGPOName = "GPO-$($platform)-BG-Svrs-$($AD_Environment)-$($AppOU)-$($serviceTypeOU)-v$i.0" 
$GPOExist = 'True'
}
else
{
$GPOExist = 'False'
$newGPO = Copy-GPO -SourceName $templateGPO -TargetName $newGPOName -SourceDomainController "ZSCPWDCS001.uk.centricaplc.com" -TargetDomainController "ZSCPWDCS001.uk.centricaplc.com"
}

$i = $i+1
}until ($GPOExist -eq 'False')

#sleep -Seconds 30

cd "\\ZSCPWDCS001.uk.centricaplc.com\sysvol\$env:USERDNSDOMAIN\Policies\{$($newGPO.id)}\Machine\microsoft\windows nt\SecEdit"
#cd "\\ST1PWDCS716.uk.centricaplc.com\sysvol\$env:USERDNSDOMAIN\Policies\{$($newGPO.id)}\Machine\microsoft\windows nt\SecEdit"
#\\ST1PWDCS716.uk.centricaplc.com\sysVOL\uk.centricaplc.com\Policies\{CD893A60-0D36-4365-B6D1-97D91DE12C50}\Machine\microsoft\windows nt\SecEdit

$GPFilePath = "\\ZSCPWDCS001.uk.centricaplc.com\sysvol\$env:USERDNSDOMAIN\Policies\{$($newGPO.id)}\Machine\microsoft\windows nt\SecEdit\GptTmpl.inf"



$lines = Get-Content $GPFilePath
$lines | where { $_ -eq $lines[0] -or $_ -eq $lines[1] -or $_ -eq $lines[2] -or $_ -eq $lines[3] -or $_ -eq $lines[4] } | out-file $GPFilePath
Add-Content -path $GPFilePath -value "[Group Membership]"
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-2].SID.Value)__Memberof = *S-1-5-32-544"
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-2].SID.Value)__Members ="
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-1].SID.Value)__Memberof = *S-1-5-32-555"
Add-Content -path $GPFilePath -value "*$($newDLGroups[$NewDLGroups.Count-1].SID.Value)__Members ="
Add-Content -path $GPFilePath -value "[Privilege Rights]"
Add-Content -path $GPFilePath -value "SeBatchLogonRight = *$AllServersSeBatchLogonRight,*$NewDLSeBatchLogonRight,*S-1-5-32-544,*S-1-5-32-551"
Add-Content -path $GPFilePath -value "SeServiceLogonRight = *$AllServersSeServiceLogonRight,*$NewDLSeServiceLogonRight"
Add-Content -path $GPFilePath -value "SeSecurityPrivilege = *$AllServersSeSecurityPrivilege,*$NewDLSeSecurityPrivilege,*S-1-5-32-544"

# Apply GPO delegation
Set-GPPermission -Name $newGPO.DisplayName -PermissionLevel GpoEdit -TargetName "d-GPO-$platform-BG-$AD_Environment-Edit" -TargetType Group -Server "ZSCPWDCS001.uk.centricaplc.com"


$serviceTypeOU
$AppOU
$AD_Environment
$platform
$newGPO.id.Guid

#sleep -Seconds 300

# Link GPO to the Target OU OU=Web,OU=DevOps,OU=Dev,OU=Servers,OU=BG,OU=SPD-Azure,DC=UK,DC=centricaplc,DC=com
New-GPLink -Guid $newGPO.Id -Target "OU=$serviceTypeOU,OU=$AppOU,OU=$AD_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=centricaplc,DC=com" -LinkEnabled Yes -Server "ZSCPWDCS001.uk.centricaplc.com"
#New-GPLink -Guid $newGPO.id.Guid -Target "OU=$serviceTypeOU,OU=$AppOU,OU=$AD_Environment,OU=Servers,OU=BG,OU=$platform,DC=uk,DC=centricaplc,DC=com" -LinkEnabled Yes

#get-gpo -id "68cb29b3-e23b-4e19-a549-6ec16ae47887"
#New-GPLink -Guid "99593056-f35f-44f5-b0fe-71fc9167006c" -Target "OU=Web,OU=mibTest01,OU=Dev,OU=Servers,OU=BG,OU=SPD-Azure,DC=uk,DC=centricaplc,DC=com" -LinkEnabled Yes

